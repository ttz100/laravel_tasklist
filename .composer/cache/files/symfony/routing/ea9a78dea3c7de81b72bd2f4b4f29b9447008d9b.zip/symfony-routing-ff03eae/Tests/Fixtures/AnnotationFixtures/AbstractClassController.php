<?php

namespace Symfony\Component\Routing\Tests\Fixtures\AnnotationFixtures;

abstract class AbstractClassController
{
}
